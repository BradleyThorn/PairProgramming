package com.meritamerica.assignment3;


import java.util.*;
import java.util.Iterator;
//file reading notes:
//

public class MeritAmericaBankApp {
	public static void main(String[] args) 
	{
		
		MeritBank.readFromFile("src/test/testMeritBank_good.txt");
		
		AccountHolder[] ac = MeritBank.getAccountHolders();
		System.out.println(ac.length);
		System.out.println(ac[0].getCombinedBalance());
		System.out.println(ac[1].getCombinedBalance());
		
		AccountHolder[] sortedAccountHolders = MeritBank.sortAccountHolders();    	
    	
		System.out.println(sortedAccountHolders[0].getCombinedBalance());
		System.out.println(sortedAccountHolders[1].getCombinedBalance());
    	
		
		
	}
}